import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { User } from '../models/User.js';
import { Product } from '../models/Product.js';
import { Order } from '../models/Order.js';
import { initialProducts } from '../data/products.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbFilePath = path.join(__dirname, '..', 'db.json');

// Helper to check if MongoDB is connected
function isConnected() {
  return !!global.isMongoConnected;
}

// JSON file DB helpers
function readJSONDb() {
  if (!fs.existsSync(dbFilePath)) {
    const initialDb = {
      users: [],
      products: initialProducts.map((p, idx) => ({ _id: `prd_${idx + 1}`, ...p })),
      orders: []
    };
    fs.writeFileSync(dbFilePath, JSON.stringify(initialDb, null, 2), 'utf-8');
    return initialDb;
  }
  try {
    const data = fs.readFileSync(dbFilePath, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading JSON DB, reinitializing:', err);
    const initialDb = {
      users: [],
      products: initialProducts.map((p, idx) => ({ _id: `prd_${idx + 1}`, ...p })),
      orders: []
    };
    fs.writeFileSync(dbFilePath, JSON.stringify(initialDb, null, 2), 'utf-8');
    return initialDb;
  }
}

function writeJSONDb(data) {
  fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2), 'utf-8');
}

export const dbStore = {
  // USER OPERATIONS
  async findUserByEmail(email) {
    if (isConnected()) {
      return await User.findOne({ email: email.toLowerCase() });
    } else {
      const db = readJSONDb();
      const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
      return user || null;
    }
  },

  async createUser({ name, email, password }) {
    if (isConnected()) {
      const newUser = new User({ name, email: email.toLowerCase(), password });
      return await newUser.save();
    } else {
      const db = readJSONDb();
      const newUser = {
        _id: `usr_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        name,
        email: email.toLowerCase(),
        password,
        createdAt: new Date()
      };
      db.users.push(newUser);
      writeJSONDb(db);
      return newUser;
    }
  },

  async findUserById(id) {
    if (isConnected()) {
      return await User.findById(id).select('-password');
    } else {
      const db = readJSONDb();
      const user = db.users.find(u => u._id === id);
      if (!user) return null;
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    }
  },

  async updateUserPassword(id, hashedPassword) {
    if (isConnected()) {
      return await User.findByIdAndUpdate(id, { password: hashedPassword });
    } else {
      const db = readJSONDb();
      const userIndex = db.users.findIndex(u => u._id === id);
      if (userIndex !== -1) {
        db.users[userIndex].password = hashedPassword;
        writeJSONDb(db);
        return true;
      }
      return false;
    }
  },

  // PRODUCT OPERATIONS
  async getProducts(search = '', category = '') {
    if (isConnected()) {
      const query = {};
      if (category) {
        query.category = category;
      }
      if (search) {
        query.name = { $regex: search, $options: 'i' };
      }
      return await Product.find(query);
    } else {
      const db = readJSONDb();
      let results = db.products;
      if (category) {
        results = results.filter(p => p.category.toLowerCase() === category.toLowerCase());
      }
      if (search) {
        const searchLower = search.toLowerCase();
        results = results.filter(p => p.name.toLowerCase().includes(searchLower));
      }
      return results;
    }
  },

  async getProductById(id) {
    if (isConnected()) {
      return await Product.findById(id);
    } else {
      const db = readJSONDb();
      const product = db.products.find(p => p._id === id);
      return product || null;
    }
  },

  async updateProductStock(id, newStock) {
    if (isConnected()) {
      return await Product.findByIdAndUpdate(id, { stock: newStock }, { new: true });
    } else {
      const db = readJSONDb();
      const productIndex = db.products.findIndex(p => p._id === id);
      if (productIndex !== -1) {
        db.products[productIndex].stock = newStock;
        writeJSONDb(db);
        return db.products[productIndex];
      }
      return null;
    }
  },

  // ORDER OPERATIONS
  async createOrder({ user, items, shippingAddress, paymentMethod, totalPrice }) {
    if (isConnected()) {
      const newOrder = new Order({
        user,
        items,
        shippingAddress,
        paymentMethod,
        totalPrice,
        paymentStatus: paymentMethod === 'Online Payment' ? 'Paid' : 'Pending'
      });
      return await newOrder.save();
    } else {
      const db = readJSONDb();
      const newOrder = {
        _id: `ord_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        user,
        items,
        shippingAddress,
        paymentMethod,
        paymentStatus: paymentMethod === 'Online Payment' ? 'Paid' : 'Pending',
        totalPrice,
        status: 'Processing',
        createdAt: new Date()
      };
      db.orders.push(newOrder);
      writeJSONDb(db);
      return newOrder;
    }
  },

  async getOrdersByUser(userId) {
    if (isConnected()) {
      return await Order.find({ user: userId }).sort({ createdAt: -1 });
    } else {
      const db = readJSONDb();
      const userOrders = db.orders.filter(o => o.user === userId);
      // Sort by date descending
      return userOrders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }
  }
};
