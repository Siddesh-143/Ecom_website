import mongoose from 'mongoose';
import { Product } from '../models/Product.js';
import { initialProducts } from '../data/products.js';

export async function connectDB() {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/aura_ecom');
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    global.isMongoConnected = true;

    // Seed products if empty
    const count = await Product.countDocuments();
    if (count === 0) {
      await Product.insertMany(initialProducts);
      console.log('Database seeded with 16 products.');
    }
  } catch (error) {
    console.warn(`MongoDB connection failed: ${error.message}. Falling back to file-based database (db.json).`);
    global.isMongoConnected = false;
  }
}
