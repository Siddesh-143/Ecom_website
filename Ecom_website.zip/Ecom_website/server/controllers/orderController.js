import { dbStore } from '../config/store.js';

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
export const createOrder = async (req, res) => {
  const { items, shippingAddress, paymentMethod, totalPrice } = req.body;

  if (!items || items.length === 0) {
    return res.status(400).json({ message: 'No order items' });
  }

  if (!shippingAddress || !paymentMethod || !totalPrice) {
    return res.status(400).json({ message: 'Missing order details' });
  }

  try {
    // Check stock for all items first
    for (const item of items) {
      const product = await dbStore.getProductById(item.product);
      if (!product) {
        return res.status(404).json({ message: `Product not found: ${item.name}` });
      }
      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `Insufficient stock for ${product.name}. Available: ${product.stock}` });
      }
    }

    // Deduct stock
    for (const item of items) {
      const product = await dbStore.getProductById(item.product);
      const newStock = product.stock - item.quantity;
      await dbStore.updateProductStock(item.product, newStock);
    }

    // Create Order
    const order = await dbStore.createOrder({
      user: req.user._id.toString(),
      items,
      shippingAddress,
      paymentMethod,
      totalPrice
    });

    res.status(201).json(order);
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ message: 'Server error creating order' });
  }
};

// @desc    Get logged in user orders
// @route   GET /api/orders/myorders
// @access  Private
export const getMyOrders = async (req, res) => {
  try {
    const orders = await dbStore.getOrdersByUser(req.user._id.toString());
    res.json(orders);
  } catch (error) {
    console.error('Fetch orders error:', error);
    res.status(500).json({ message: 'Server error fetching user orders' });
  }
};
