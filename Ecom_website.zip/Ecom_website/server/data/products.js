export const initialProducts = [
  // Electronics
  {
    name: "Aura Pro Sound Wireless Headphones",
    category: "Electronics",
    price: 299.99,
    rating: 4.8,
    reviewsCount: 142,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80",
    description: "Experience premium acoustics with active hybrid noise cancellation, 40-hour battery life, and spatial audio capabilities designed for audiophiles.",
    stock: 12
  },
  {
    name: "AuraBook Elite 14\" Laptop",
    category: "Electronics",
    price: 1299.99,
    rating: 4.9,
    reviewsCount: 88,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&auto=format&fit=crop&q=80",
    description: "Next-generation computing powered by an ultra-efficient processor, 16GB RAM, 512GB NVMe SSD, and a gorgeous QHD+ borderless IPS display.",
    stock: 8
  },
  {
    name: "AuraSphere Smart Assistant Speaker",
    category: "Electronics",
    price: 79.99,
    rating: 4.5,
    reviewsCount: 310,
    image: "https://images.unsplash.com/photo-1543512214-318c7553f230?w=800&auto=format&fit=crop&q=80",
    description: "Intelligent speaker with immersive 360-degree sound, smart home integration, voice assistant compatibility, and premium fabric finish.",
    stock: 25
  },
  {
    name: "AuraView 34\" Curved Gaming Monitor",
    category: "Electronics",
    price: 499.99,
    rating: 4.7,
    reviewsCount: 64,
    image: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=800&auto=format&fit=crop&q=80",
    description: "Ultra-wide 1500R curved monitor featuring a 165Hz refresh rate, 1ms response time, HDR400, and AMD FreeSync Premium for seamless gameplay.",
    stock: 5
  },

  // Fashion
  {
    name: "Classic Obsidian Leather Jacket",
    category: "Fashion",
    price: 189.99,
    rating: 4.6,
    reviewsCount: 112,
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&auto=format&fit=crop&q=80",
    description: "Handcrafted from 100% premium full-grain leather, featuring robust hardware, tailored fit, and a timeless aesthetic that ages beautifully.",
    stock: 14
  },
  {
    name: "Aura Signature Trench Coat",
    category: "Fashion",
    price: 249.99,
    rating: 4.8,
    reviewsCount: 75,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800&auto=format&fit=crop&q=80",
    description: "A double-breasted silhouette made of water-resistant gabardine cotton. Features adjustable belted cuffs and a modern tailored drape.",
    stock: 10
  },
  {
    name: "Minimalist Sand Linen Shirt",
    category: "Fashion",
    price: 59.99,
    rating: 4.4,
    reviewsCount: 198,
    image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&auto=format&fit=crop&q=80",
    description: "Lightweight and breathable shirt tailored from premium flax linen. Perfect for warm climates, featuring a soft relaxed collar.",
    stock: 30
  },
  {
    name: "Aviator Gold-Frame Sunglasses",
    category: "Fashion",
    price: 120.00,
    rating: 4.7,
    reviewsCount: 153,
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&auto=format&fit=crop&q=80",
    description: "Classic aviator sunglasses with polarized UV400 lenses, lightweight 18k gold-plated titanium frames, and comfortable silicone nose pads.",
    stock: 18
  },

  // Shoes
  {
    name: "Aura HyperGlide Running Shoes",
    category: "Shoes",
    price: 139.99,
    rating: 4.7,
    reviewsCount: 220,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80",
    description: "High-performance running shoes featuring responsive foam cushioning, engineered mesh upper, and carbon fiber plate for maximum energy return.",
    stock: 16
  },
  {
    name: "Rugged Chestnut Leather Boots",
    category: "Shoes",
    price: 179.99,
    rating: 4.8,
    reviewsCount: 94,
    image: "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=800&auto=format&fit=crop&q=80",
    description: "Durable, water-resistant leather boots with a Goodyear welt construction and heavy-duty Vibram outsole, ready for city streets or mountain trails.",
    stock: 9
  },
  {
    name: "Urban Retro Canvas Sneakers",
    category: "Shoes",
    price: 69.99,
    rating: 4.3,
    reviewsCount: 145,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=80",
    description: "Versatile low-top sneakers crafted from durable canvas with a reinforced rubber toe cap and cushioned footbed for all-day comfort.",
    stock: 40
  },
  {
    name: "Sleek Charcoal Suede Loafers",
    category: "Shoes",
    price: 149.99,
    rating: 4.6,
    reviewsCount: 82,
    image: "https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=800&auto=format&fit=crop&q=80",
    description: "Refined Italian suede loafers with a slip-on design, hand-stitched detailing, and a flexible leather sole. Perfect for smart-casual wear.",
    stock: 15
  },

  // Watches
  {
    name: "Aura Minimalist Chronograph",
    category: "Watches",
    price: 199.99,
    rating: 4.6,
    reviewsCount: 128,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80",
    description: "A sleek watch featuring a surgical-grade stainless steel case, sapphire crystal glass, Japanese quartz movement, and premium mesh band.",
    stock: 10
  },
  {
    name: "Aura Peak Adventure Smartwatch",
    category: "Watches",
    price: 349.99,
    rating: 4.8,
    reviewsCount: 92,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop&q=80",
    description: "All-terrain smartwatch with built-in GPS, barometric altimeter, heart rate monitoring, offline mapping, and a rugged titanium bezel.",
    stock: 7
  },
  {
    name: "Heritage 24k Gold Dress Watch",
    category: "Watches",
    price: 450.00,
    rating: 4.9,
    reviewsCount: 50,
    image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800&auto=format&fit=crop&q=80",
    description: "Exquisite dress watch with a 24k gold-plated case, automatic self-winding movement, Roman numerals, and a genuine alligator leather strap.",
    stock: 4
  },
  {
    name: "DeepSea Titanium Diver Watch",
    category: "Watches",
    price: 399.99,
    rating: 4.7,
    reviewsCount: 77,
    image: "https://images.unsplash.com/photo-1622434641406-a158123450f9?w=800&auto=format&fit=crop&q=80",
    description: "Professional diving watch water-resistant up to 300 meters, featuring a unidirectional rotating bezel, super-luminova hands, and lightweight titanium construction.",
    stock: 11
  }
];
