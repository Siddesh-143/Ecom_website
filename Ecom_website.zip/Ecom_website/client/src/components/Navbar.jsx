import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { ShoppingCart, User, Search, Menu, X, LogOut, Package, Sparkles } from 'lucide-react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { totalItems } = useCart();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/catalog?search=${encodeURIComponent(searchQuery.trim())}`);
      setIsMobileMenuOpen(false);
    }
  };

  const handleCategoryClick = (category) => {
    navigate(`/catalog?category=${category}`);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="glass sticky top-0 z-50 transition-all duration-300 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center glow-primary transition-transform duration-300 group-hover:scale-105">
                <Sparkles className="w-5 h-5 text-white animate-pulse" />
              </div>
              <span className="font-extrabold text-2xl tracking-tight bg-gradient-to-r from-blue-400 via-indigo-200 to-purple-400 bg-clip-text text-transparent group-hover:opacity-90 transition-opacity">
                AURA<span className="text-white font-medium text-lg ml-0.5">LUX</span>
              </span>
            </Link>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-1">
            <Link to="/" className="text-slate-300 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition-colors">
              Home
            </Link>
            <button onClick={() => handleCategoryClick('Electronics')} className="text-slate-300 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition-colors">
              Electronics
            </button>
            <button onClick={() => handleCategoryClick('Fashion')} className="text-slate-300 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition-colors">
              Fashion
            </button>
            <button onClick={() => handleCategoryClick('Shoes')} className="text-slate-300 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition-colors">
              Shoes
            </button>
            <button onClick={() => handleCategoryClick('Watches')} className="text-slate-300 hover:text-white px-3 py-2 rounded-lg text-sm font-medium transition-colors">
              Watches
            </button>
          </div>

          {/* Desktop Search Bar */}
          <div className="hidden lg:block flex-1 max-w-xs mx-4">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                placeholder="Search premium products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900/60 border border-slate-700/80 rounded-full py-2 pl-4 pr-10 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
              />
              <button type="submit" className="absolute right-3 top-2.5 text-slate-400 hover:text-white transition-colors">
                <Search className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Right Side: Profile & Cart */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Cart Icon */}
            <Link to="/cart" className="relative p-2 text-slate-300 hover:text-white transition-colors group">
              <ShoppingCart className="w-6 h-6 transition-transform group-hover:scale-105" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-lg border border-slate-950">
                  {totalItems}
                </span>
              )}
            </Link>

            {/* Profile / Dropdown */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                  onBlur={() => setTimeout(() => setIsProfileDropdownOpen(false), 200)}
                  className="flex items-center gap-2 p-1.5 rounded-full border border-slate-700 hover:border-slate-500 transition-all focus:outline-none"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                </button>

                {isProfileDropdownOpen && (
                  <div className="absolute right-0 mt-3 w-48 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl py-2 z-50 transform origin-top-right transition-all">
                    <div className="px-4 py-2 border-b border-slate-800">
                      <p className="text-xs text-slate-500">Logged in as</p>
                      <p className="text-sm font-semibold text-white truncate">{user.name}</p>
                    </div>
                    <Link to="/profile" className="flex items-center gap-2 px-4 py-2 text-sm text-slate-300 hover:bg-slate-800 hover:text-white transition-colors">
                      <Package className="w-4 h-4" /> My Profile
                    </Link>
                    <button
                      onClick={logout}
                      className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:bg-slate-800 hover:text-red-300 transition-colors text-left"
                    >
                      <LogOut className="w-4 h-4" /> Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="bg-slate-900 border border-slate-700 hover:border-slate-500 text-white px-5 py-2 rounded-xl text-sm font-semibold transition-all hover:bg-slate-950 flex items-center gap-2"
              >
                <User className="w-4 h-4" /> Sign In
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden gap-4">
            <Link to="/cart" className="relative p-2 text-slate-300 hover:text-white">
              <ShoppingCart className="w-6 h-6" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-lg border border-slate-950">
                  {totalItems}
                </span>
              )}
            </Link>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white focus:outline-none"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden glass border-t border-slate-800 animate-fadeIn">
          <div className="px-2 pt-4 pb-3 space-y-1">
            {/* Search in mobile */}
            <div className="px-3 mb-4">
              <form onSubmit={handleSearchSubmit} className="relative">
                <input
                  type="text"
                  placeholder="Search premium products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-full py-2 pl-4 pr-10 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                />
                <button type="submit" className="absolute right-3 top-2.5 text-slate-400">
                  <Search className="w-4 h-4" />
                </button>
              </form>
            </div>

            <Link
              to="/"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block text-slate-300 hover:text-white px-3 py-2 rounded-lg text-base font-medium"
            >
              Home
            </Link>
            <button
              onClick={() => handleCategoryClick('Electronics')}
              className="w-full text-left block text-slate-300 hover:text-white px-3 py-2 rounded-lg text-base font-medium"
            >
              Electronics
            </button>
            <button
              onClick={() => handleCategoryClick('Fashion')}
              className="w-full text-left block text-slate-300 hover:text-white px-3 py-2 rounded-lg text-base font-medium"
            >
              Fashion
            </button>
            <button
              onClick={() => handleCategoryClick('Shoes')}
              className="w-full text-left block text-slate-300 hover:text-white px-3 py-2 rounded-lg text-base font-medium"
            >
              Shoes
            </button>
            <button
              onClick={() => handleCategoryClick('Watches')}
              className="w-full text-left block text-slate-300 hover:text-white px-3 py-2 rounded-lg text-base font-medium"
            >
              Watches
            </button>

            <div className="border-t border-slate-800 pt-4 mt-4">
              {user ? (
                <>
                  <div className="px-3 mb-2">
                    <p className="text-xs text-slate-500">Logged in as</p>
                    <p className="text-sm font-semibold text-white">{user.name}</p>
                  </div>
                  <Link
                    to="/profile"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block text-slate-300 hover:text-white px-3 py-2 rounded-lg text-base font-medium"
                  >
                    My Profile
                  </Link>
                  <button
                    onClick={() => {
                      logout();
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full text-left block text-red-400 hover:text-red-300 px-3 py-2 rounded-lg text-base font-medium"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block text-center bg-gradient-to-r from-blue-600 to-purple-600 text-white mx-3 my-2 py-2.5 rounded-xl text-base font-semibold"
                >
                  Sign In
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
