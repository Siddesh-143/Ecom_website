import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Mail, Phone, MapPin, Code, Globe, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 text-slate-400 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center glow-primary">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-blue-400 via-indigo-200 to-purple-400 bg-clip-text text-transparent">
                AURA<span className="text-white font-medium text-base ml-0.5">LUX</span>
              </span>
            </Link>
            <p className="text-sm text-slate-400 leading-relaxed">
              Experience the pinnacle of luxury commerce. Carefully curated premium goods with effortless performance, shipped worldwide.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-blue-400 transition-colors"><Globe className="w-5 h-5" /></a>
              <a href="#" className="hover:text-purple-400 transition-colors"><Heart className="w-5 h-5" /></a>
              <a href="#" className="hover:text-white transition-colors"><Code className="w-5 h-5" /></a>
            </div>
          </div>

          {/* Quick Categories */}
          <div>
            <h3 className="text-white font-bold text-sm tracking-wider uppercase mb-4">Categories</h3>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/catalog?category=Electronics" className="hover:text-white transition-colors">Electronics</Link></li>
              <li><Link to="/catalog?category=Fashion" className="hover:text-white transition-colors">Fashion</Link></li>
              <li><Link to="/catalog?category=Shoes" className="hover:text-white transition-colors">Shoes</Link></li>
              <li><Link to="/catalog?category=Watches" className="hover:text-white transition-colors">Watches</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-white font-bold text-sm tracking-wider uppercase mb-4">Customer Care</h3>
            <ul className="space-y-2.5 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Track Your Order</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">FAQs</a></li>
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-white font-bold text-sm tracking-wider uppercase mb-4">Get In Touch</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-blue-500 mt-0.5" />
                <span>100 Luxury Avenue, Suite 500, New York, NY 10001</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-blue-500" />
                <span>+1 (800) 555-AURA</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-blue-500" />
                <span>support@auralux.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copywrite Section */}
        <div className="border-t border-slate-900 pt-8 mt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-slate-500">&copy; {new Date().getFullYear()} Aura Lux E-Commerce. All rights reserved.</p>
          <div className="flex gap-6 text-xs text-slate-500">
            <a href="#" className="hover:text-slate-400">Privacy Policy</a>
            <a href="#" className="hover:text-slate-400">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
