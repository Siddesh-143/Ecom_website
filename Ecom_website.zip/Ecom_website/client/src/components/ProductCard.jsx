import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Star, ShoppingCart, Eye } from 'lucide-react';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalf = rating % 1 !== 0;

    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />);
      } else if (i === fullStars + 1 && hasHalf) {
        stars.push(
          <div key={i} className="relative">
            <Star className="w-4 h-4 text-slate-600" />
            <div className="absolute top-0 left-0 overflow-hidden w-1/2">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            </div>
          </div>
        );
      } else {
        stars.push(<Star key={i} className="w-4 h-4 text-slate-600" />);
      }
    }
    return stars;
  };

  return (
    <div className="group relative rounded-3xl bg-slate-900/40 border border-slate-800/80 hover:border-blue-500/40 transition-all duration-300 flex flex-col h-full overflow-hidden hover:shadow-[0_15px_30px_-10px_rgba(59,130,246,0.25)]">
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-slate-950">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          loading="lazy"
        />

        {/* Hover overlay actions */}
        <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
          <Link
            to={`/product/${product._id}`}
            className="w-12 h-12 rounded-full bg-white text-slate-950 flex items-center justify-center hover:bg-blue-500 hover:text-white transition-all transform translate-y-4 group-hover:translate-y-0 duration-300"
            title="View Details"
          >
            <Eye className="w-5 h-5" />
          </Link>
          <button
            onClick={() => addToCart(product)}
            disabled={product.stock <= 0}
            className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-600 transition-all transform translate-y-4 group-hover:translate-y-0 duration-300 delay-75"
            title={product.stock > 0 ? "Add to Cart" : "Out of Stock"}
          >
            <ShoppingCart className="w-5 h-5" />
          </button>
        </div>

        {/* Category tag */}
        <span className="absolute top-4 left-4 bg-slate-900/80 backdrop-blur-md border border-slate-700 text-slate-300 text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider">
          {product.category}
        </span>

        {/* Stock Warning */}
        {product.stock <= 0 ? (
          <span className="absolute top-4 right-4 bg-red-900/90 text-red-100 text-xs font-bold px-3 py-1 rounded-full border border-red-700">
            Sold Out
          </span>
        ) : product.stock <= 5 ? (
          <span className="absolute top-4 right-4 bg-amber-900/90 text-amber-100 text-xs font-bold px-3 py-1 rounded-full border border-amber-700">
            Only {product.stock} Left
          </span>
        ) : null}
      </div>

      {/* Details Container */}
      <div className="p-6 flex flex-col flex-grow">
        {/* Rating */}
        <div className="flex items-center gap-1 mb-2.5">
          <div className="flex">{renderStars(product.rating)}</div>
          <span className="text-xs text-slate-500 ml-1">({product.reviewsCount || 0})</span>
        </div>

        {/* Title */}
        <h3 className="font-semibold text-lg text-white mb-2 line-clamp-1 group-hover:text-blue-400 transition-colors">
          <Link to={`/product/${product._id}`}>{product.name}</Link>
        </h3>

        {/* Description snippet */}
        <p className="text-sm text-slate-400 line-clamp-2 mb-4 flex-grow">
          {product.description}
        </p>

        {/* Price & Action */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800/60">
          <span className="font-bold text-xl text-white">
            ${product.price.toFixed(2)}
          </span>
          <button
            onClick={() => addToCart(product)}
            disabled={product.stock <= 0}
            className="text-xs font-bold text-blue-400 hover:text-white flex items-center gap-1.5 transition-colors disabled:text-slate-600 disabled:hover:text-slate-600"
          >
            {product.stock > 0 ? (
              <>
                <ShoppingCart className="w-3.5 h-3.5" />
                ADD TO CART
              </>
            ) : (
              'OUT OF STOCK'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
