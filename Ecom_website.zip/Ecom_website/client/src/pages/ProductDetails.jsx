import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { Star, ShoppingCart, CreditCard, ArrowLeft, Shield, Truck, RefreshCw } from 'lucide-react';

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { apiRequest } = useAuth();
  const { addToCart } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      try {
        const data = await apiRequest(`/products/${id}`);
        setProduct(data);
      } catch (err) {
        console.error(err);
        setError('Product not found.');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity);
    }
  };

  const handleBuyNow = () => {
    if (product) {
      addToCart(product, quantity);
      navigate('/checkout');
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalf = rating % 1 !== 0;

    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />);
      } else if (i === fullStars + 1 && hasHalf) {
        stars.push(
          <div key={i} className="relative">
            <Star className="w-5 h-5 text-slate-600" />
            <div className="absolute top-0 left-0 overflow-hidden w-1/2">
              <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
            </div>
          </div>
        );
      } else {
        stars.push(<Star key={i} className="w-5 h-5 text-slate-600" />);
      }
    }
    return stars;
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="animate-pulse grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-slate-900/50 border border-slate-800 rounded-3xl aspect-square"></div>
          <div className="space-y-6">
            <div className="h-10 bg-slate-900/50 rounded-2xl w-3/4"></div>
            <div className="h-6 bg-slate-900/50 rounded-2xl w-1/4"></div>
            <div className="h-24 bg-slate-900/50 rounded-2xl w-full"></div>
            <div className="h-12 bg-slate-900/50 rounded-2xl w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center space-y-6">
        <h2 className="text-2xl font-bold text-white">Oops! Product not found.</h2>
        <p className="text-slate-400">The product you are looking for might have been removed or doesn't exist.</p>
        <button
          onClick={() => navigate('/catalog')}
          className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold px-6 py-3 rounded-xl transition-all"
        >
          <ArrowLeft className="w-4 h-4" /> Return to Catalog
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left space-y-8">
      {/* Back link */}
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-slate-400 hover:text-white font-semibold text-sm transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Products
      </button>

      {/* Main product card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        {/* Left: Product Image */}
        <div className="rounded-[2rem] overflow-hidden bg-slate-950 border border-slate-800 aspect-square shadow-2xl">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        {/* Right: Product details */}
        <div className="space-y-8">
          <div className="space-y-4">
            <span className="bg-blue-600/15 border border-blue-500/30 text-blue-400 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              {product.category}
            </span>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white leading-tight">{product.name}</h1>

            {/* Ratings and Reviews */}
            <div className="flex items-center gap-2 pt-2">
              <div className="flex">{renderStars(product.rating)}</div>
              <span className="text-sm font-semibold text-white ml-2">{product.rating}</span>
              <span className="text-slate-500">•</span>
              <span className="text-sm text-slate-400 font-medium">{product.reviewsCount || 0} reviews</span>
            </div>
          </div>

          {/* Pricing & Stock */}
          <div className="p-6 rounded-3xl bg-slate-900/40 border border-slate-800 space-y-4">
            <div className="flex items-baseline gap-4">
              <span className="text-4xl font-extrabold text-white">${product.price.toFixed(2)}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-400">Availability:</span>
              {product.stock > 0 ? (
                <span className="text-sm font-bold text-emerald-400">In Stock ({product.stock} units)</span>
              ) : (
                <span className="text-sm font-bold text-red-400">Out of Stock</span>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Description</h3>
            <p className="text-slate-300 leading-relaxed text-base">{product.description}</p>
          </div>

          {/* Quantity selector and checkout actions */}
          {product.stock > 0 && (
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <span className="text-sm font-bold text-slate-400 uppercase tracking-wider">Quantity:</span>
                <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-4 py-2 text-slate-400 hover:text-white font-bold transition-colors"
                  >
                    -
                  </button>
                  <span className="px-4 text-white font-bold">{quantity}</span>
                  <button
                    onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                    className="px-4 py-2 text-slate-400 hover:text-white font-bold transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  onClick={handleAddToCart}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 px-6 rounded-2xl border border-slate-800 transition-all flex items-center justify-center gap-2.5 shadow-lg"
                >
                  <ShoppingCart className="w-5 h-5 text-blue-400" /> Add to Cart
                </button>
                <button
                  onClick={handleBuyNow}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold py-4 px-6 rounded-2xl transition-all flex items-center justify-center gap-2.5 shadow-xl hover:shadow-[0_8px_30px_rgb(59,130,246,0.3)]"
                >
                  <CreditCard className="w-5 h-5" /> Buy It Now
                </button>
              </div>
            </div>
          )}

          {/* Luxury assurance labels */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-800/60 text-xs text-slate-400">
            <div className="flex items-center gap-2.5">
              <Truck className="w-4 h-4 text-blue-500" />
              <span>Complimentary Shipping</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Shield className="w-4 h-4 text-blue-500" />
              <span>2 Year Official Warranty</span>
            </div>
            <div className="flex items-center gap-2.5">
              <RefreshCw className="w-4 h-4 text-blue-500" />
              <span>30-Day Premium Return</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
