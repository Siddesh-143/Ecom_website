import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Trash2, ArrowLeft, ShoppingBag, ArrowRight } from 'lucide-react';

export default function Cart() {
  const { cartItems, totalPrice, totalItems, updateQuantity, removeFromCart } = useCart();
  const navigate = useNavigate();

  if (cartItems.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-20 h-20 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center mx-auto text-slate-500">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-extrabold text-white">Your cart is empty</h2>
        <p className="text-slate-400 max-w-md mx-auto">
          Explore our select collections of luxury items and find something that suits your style.
        </p>
        <Link
          to="/catalog"
          className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold px-8 py-3.5 rounded-2xl shadow-xl transition-all"
        >
          <ArrowLeft className="w-4 h-4" /> Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left space-y-8">
      <div>
        <h1 className="text-4xl font-extrabold text-white">Shopping Cart</h1>
        <p className="text-sm text-slate-400 mt-1">Verify your selections and proceed to payment.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Cart items list */}
        <div className="lg:col-span-2 space-y-4">
          {cartItems.map((item) => (
            <div
              key={item.product}
              className="flex flex-col sm:flex-row items-center gap-6 p-6 rounded-3xl bg-slate-900/40 border border-slate-800/80"
            >
              {/* Product Image */}
              <div className="w-24 h-24 rounded-2xl overflow-hidden bg-slate-950 flex-shrink-0 border border-slate-800">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              </div>

              {/* Product Details */}
              <div className="flex-grow text-center sm:text-left space-y-1">
                <Link
                  to={`/product/${item.product}`}
                  className="font-bold text-lg text-white hover:text-blue-400 transition-colors line-clamp-1"
                >
                  {item.name}
                </Link>
                <p className="text-sm font-semibold text-slate-400">${item.price.toFixed(2)}</p>
              </div>

              {/* Quantity Changer */}
              <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                <button
                  onClick={() => updateQuantity(item.product, item.quantity - 1)}
                  className="px-3.5 py-1.5 text-slate-400 hover:text-white font-bold transition-colors"
                >
                  -
                </button>
                <span className="px-3 text-white font-bold text-sm">{item.quantity}</span>
                <button
                  onClick={() => updateQuantity(item.product, item.quantity + 1)}
                  className="px-3.5 py-1.5 text-slate-400 hover:text-white font-bold transition-colors"
                >
                  +
                </button>
              </div>

              {/* Delete Button */}
              <button
                onClick={() => removeFromCart(item.product)}
                className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-red-400 hover:border-red-500/25 transition-all"
                title="Remove item"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1 p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-6">
          <h3 className="font-bold text-white text-xl pb-4 border-b border-slate-800">Order Summary</h3>

          <div className="space-y-4 text-sm text-slate-400">
            <div className="flex justify-between">
              <span>Total items</span>
              <span className="font-semibold text-white">{totalItems}</span>
            </div>
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-semibold text-white">${totalPrice.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping</span>
              <span className="font-semibold text-emerald-400">Complimentary</span>
            </div>
            <div className="border-t border-slate-800 pt-4 flex justify-between text-base text-white font-bold">
              <span>Estimated Total</span>
              <span className="text-xl font-extrabold text-white">${totalPrice.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={() => navigate('/checkout')}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold py-4 px-6 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-xl hover:shadow-[0_8px_30px_rgb(59,130,246,0.3)]"
          >
            Proceed to Checkout <ArrowRight className="w-5 h-5" />
          </button>

          <Link
            to="/catalog"
            className="block text-center text-xs font-semibold text-slate-400 hover:text-white transition-colors"
          >
            Or continue shopping
          </Link>
        </div>
      </div>
    </div>
  );
}
