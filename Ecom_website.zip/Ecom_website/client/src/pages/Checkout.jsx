import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { ShieldCheck, CreditCard, Wallet, ArrowLeft, Loader2 } from 'lucide-react';

export default function Checkout() {
  const { user, apiRequest } = useAuth();
  const { cartItems, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();

  const [shippingAddress, setShippingAddress] = useState({
    fullName: '',
    address: '',
    city: '',
    postalCode: '',
    country: ''
  });

  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');
  
  // Dummy Card State
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvv: ''
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Redirect if guest
  useEffect(() => {
    if (!user) {
      navigate('/login?redirect=checkout');
    }
  }, [user, navigate]);

  // Redirect if cart empty
  useEffect(() => {
    if (cartItems.length === 0) {
      navigate('/cart');
    }
  }, [cartItems, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setShippingAddress((prev) => ({ ...prev, [name]: value }));
  };

  const handleCardChange = (e) => {
    const { name, value } = e.target;
    setCardDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    // Basic address validation
    const { fullName, address, city, postalCode, country } = shippingAddress;
    if (!fullName || !address || !city || !postalCode || !country) {
      setError('Please fill in all shipping address fields.');
      setLoading(false);
      return;
    }

    // Dummy card validation if online payment
    if (paymentMethod === 'Online Payment') {
      const { number, expiry, cvv } = cardDetails;
      if (!number || !expiry || !cvv) {
        setError('Please complete your dummy credit card details.');
        setLoading(false);
        return;
      }
    }

    try {
      const orderData = {
        items: cartItems.map((item) => ({
          product: item.product,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          image: item.image
        })),
        shippingAddress,
        paymentMethod,
        totalPrice
      };

      // Create Order on Server
      const order = await apiRequest('/orders', {
        method: 'POST',
        body: JSON.stringify(orderData)
      });

      // Clear Cart and Navigate to success
      clearCart();
      navigate(`/success?id=${order._id}`);
    } catch (err) {
      setError(err.message || 'Error placing order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left space-y-8">
      <div>
        <h1 className="text-4xl font-extrabold text-white">Checkout</h1>
        <p className="text-sm text-slate-400 mt-1">Complete your shipping and payment configurations.</p>
      </div>

      {error && (
        <div className="p-4 bg-red-900/20 border border-red-500/30 rounded-2xl text-sm font-semibold text-red-400">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Left Columns: Shipping & Payment */}
        <div className="lg:col-span-2 space-y-8">
          {/* Shipping Address Card */}
          <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 space-y-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-600/10 text-blue-500 flex items-center justify-center text-xs">1</span>
              Shipping Address
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="sm:col-span-2 space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Full Name</label>
                <input
                  type="text"
                  name="fullName"
                  value={shippingAddress.fullName}
                  onChange={handleInputChange}
                  placeholder="John Doe"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="sm:col-span-2 space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Street Address</label>
                <input
                  type="text"
                  name="address"
                  value={shippingAddress.address}
                  onChange={handleInputChange}
                  placeholder="123 Luxury Lane"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">City</label>
                <input
                  type="text"
                  name="city"
                  value={shippingAddress.city}
                  onChange={handleInputChange}
                  placeholder="New York"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Postal Code</label>
                <input
                  type="text"
                  name="postalCode"
                  value={shippingAddress.postalCode}
                  onChange={handleInputChange}
                  placeholder="10001"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="sm:col-span-2 space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Country</label>
                <input
                  type="text"
                  name="country"
                  value={shippingAddress.country}
                  onChange={handleInputChange}
                  placeholder="United States"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                  required
                />
              </div>
            </div>
          </div>

          {/* Payment Method Card */}
          <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 space-y-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-blue-600/10 text-blue-500 flex items-center justify-center text-xs">2</span>
              Payment Method
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Cash on Delivery option */}
              <button
                type="button"
                onClick={() => setPaymentMethod('Cash on Delivery')}
                className={`p-5 rounded-2xl border text-left flex gap-4 items-start transition-all ${
                  paymentMethod === 'Cash on Delivery'
                    ? 'border-blue-600 bg-blue-600/5'
                    : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
                }`}
              >
                <Wallet className={`w-5 h-5 mt-0.5 ${paymentMethod === 'Cash on Delivery' ? 'text-blue-500' : 'text-slate-500'}`} />
                <div>
                  <h4 className="font-bold text-white text-sm">Cash on Delivery</h4>
                  <p className="text-xs text-slate-400 mt-1">Pay with physical cash upon receiving parcel.</p>
                </div>
              </button>

              {/* Online Payment option */}
              <button
                type="button"
                onClick={() => setPaymentMethod('Online Payment')}
                className={`p-5 rounded-2xl border text-left flex gap-4 items-start transition-all ${
                  paymentMethod === 'Online Payment'
                    ? 'border-blue-600 bg-blue-600/5'
                    : 'border-slate-800 hover:border-slate-700 bg-slate-950/40'
                }`}
              >
                <CreditCard className={`w-5 h-5 mt-0.5 ${paymentMethod === 'Online Payment' ? 'text-blue-500' : 'text-slate-500'}`} />
                <div>
                  <h4 className="font-bold text-white text-sm">Online Payment</h4>
                  <p className="text-xs text-slate-400 mt-1">Pay instantly with credit/debit card (dummy).</p>
                </div>
              </button>
            </div>

            {/* Dummy Card Input fields */}
            {paymentMethod === 'Online Payment' && (
              <div className="p-6 rounded-2xl bg-slate-950 border border-slate-850 grid grid-cols-1 sm:grid-cols-3 gap-4 animate-fadeIn">
                <div className="sm:col-span-3 space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Card Number</label>
                  <input
                    type="text"
                    name="number"
                    value={cardDetails.number}
                    onChange={handleCardChange}
                    placeholder="4000 1234 5678 9010"
                    maxLength="19"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                    required={paymentMethod === 'Online Payment'}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Expiry (MM/YY)</label>
                  <input
                    type="text"
                    name="expiry"
                    value={cardDetails.expiry}
                    onChange={handleCardChange}
                    placeholder="12/28"
                    maxLength="5"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                    required={paymentMethod === 'Online Payment'}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">CVV</label>
                  <input
                    type="text"
                    name="cvv"
                    value={cardDetails.cvv}
                    onChange={handleCardChange}
                    placeholder="123"
                    maxLength="3"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 px-4 text-sm text-slate-200 focus:outline-none focus:border-blue-500"
                    required={paymentMethod === 'Online Payment'}
                  />
                </div>
                <div className="sm:col-span-3 flex items-center gap-2 pt-2 text-slate-500 text-xs">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" /> Secure SSL Sandbox active. Any credit card details are encrypted locally.
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Order Review */}
        <div className="lg:col-span-1 space-y-6">
          <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-6">
            <h3 className="font-bold text-white text-xl pb-4 border-b border-slate-800">Order Summary</h3>

            {/* Cart Preview items list */}
            <div className="space-y-4 max-h-48 overflow-y-auto pr-1">
              {cartItems.map((item) => (
                <div key={item.product} className="flex gap-4 items-center justify-between text-sm">
                  <div className="flex gap-3 items-center min-w-0">
                    <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover border border-slate-800 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="font-semibold text-white truncate text-xs">{item.name}</p>
                      <p className="text-[10px] text-slate-500">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <span className="font-bold text-white text-xs">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            {/* Price Calculations */}
            <div className="space-y-4 text-xs text-slate-400 pt-4 border-t border-slate-800">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="font-semibold text-white">${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping & Insurance</span>
                <span className="font-semibold text-emerald-400">Complimentary</span>
              </div>
              <div className="border-t border-slate-800 pt-4 flex justify-between text-base text-white font-bold">
                <span>Total Charge</span>
                <span className="text-xl font-extrabold text-white">${totalPrice.toFixed(2)}</span>
              </div>
            </div>

            {/* Place Order button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 disabled:from-slate-800 disabled:to-slate-800 text-white font-bold py-4 px-6 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-xl hover:shadow-[0_8px_30px_rgb(59,130,246,0.3)]"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" /> Placing Order...
                </>
              ) : (
                <>
                  Place Order (${totalPrice.toFixed(2)})
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => navigate('/cart')}
              className="w-full text-center text-xs font-semibold text-slate-400 hover:text-white transition-colors py-1 flex items-center justify-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Return to Cart
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
