import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ProductCard from '../components/ProductCard';
import { SlidersHorizontal, Search, RefreshCw, X } from 'lucide-react';

export default function Catalog() {
  const { apiRequest } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Read search & category from URL query params
  const categoryParam = searchParams.get('category') || '';
  const searchParam = searchParams.get('search') || '';

  const categories = ['All', 'Electronics', 'Fashion', 'Shoes', 'Watches'];

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const query = [];
        if (categoryParam && categoryParam !== 'All') {
          query.push(`category=${encodeURIComponent(categoryParam)}`);
        }
        if (searchParam) {
          query.push(`search=${encodeURIComponent(searchParam)}`);
        }
        const queryString = query.length > 0 ? `?${query.join('&')}` : '';
        const data = await apiRequest(`/products${queryString}`);
        setProducts(data);
      } catch (error) {
        console.error('Error fetching catalog products:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [categoryParam, searchParam]);

  const handleCategorySelect = (category) => {
    const newParams = new URLSearchParams(searchParams);
    if (category === 'All') {
      newParams.delete('category');
    } else {
      newParams.set('category', category);
    }
    setSearchParams(newParams);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    const newParams = new URLSearchParams(searchParams);
    if (value) {
      newParams.set('search', value);
    } else {
      newParams.delete('search');
    }
    setSearchParams(newParams);
  };

  const clearAllFilters = () => {
    setSearchParams({});
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 text-left">
      {/* Header section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-extrabold text-white">Catalog</h1>
          <p className="text-sm text-slate-400 mt-1">Explore our exclusive collections of premium lifestyle goods.</p>
        </div>

        {/* Search bar inside Catalog */}
        <div className="w-full md:w-80 relative">
          <input
            type="text"
            placeholder="Search catalog..."
            value={searchParam}
            onChange={handleSearchChange}
            className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 pl-4 pr-10 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
          <Search className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
        </div>
      </div>

      {/* Filter and Content section */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* Filters Sidebar for Desktop */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-slate-900/40 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <h3 className="font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-blue-500" /> Filters
            </h3>
            {(categoryParam || searchParam) && (
              <button
                onClick={clearAllFilters}
                className="text-xs font-semibold text-red-400 hover:text-red-300 flex items-center gap-1 transition-colors"
              >
                <X className="w-3.5 h-3.5" /> Clear All
              </button>
            )}
          </div>

          {/* Categories Pill selection */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Categories</h4>
            <div className="flex flex-wrap lg:flex-col gap-2">
              {categories.map((cat) => {
                const isSelected =
                  (!categoryParam && cat === 'All') || categoryParam === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => handleCategorySelect(cat)}
                    className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                        : 'bg-slate-900/50 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Product Grid Area */}
        <div className="lg:col-span-3 space-y-8">
          {/* Active filter badges */}
          {(categoryParam || searchParam) && (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-500 font-semibold mr-1">Active filters:</span>
              {categoryParam && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-semibold text-blue-400">
                  Category: {categoryParam}
                  <button onClick={() => handleCategorySelect('All')}><X className="w-3 h-3 hover:text-white" /></button>
                </span>
              )}
              {searchParam && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-semibold text-blue-400">
                  Search: "{searchParam}"
                  <button onClick={() => {
                    const newParams = new URLSearchParams(searchParams);
                    newParams.delete('search');
                    setSearchParams(newParams);
                  }}><X className="w-3 h-3 hover:text-white" /></button>
                </span>
              )}
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse bg-slate-900/50 border border-slate-800 rounded-3xl aspect-[3/4]"></div>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="p-12 rounded-3xl bg-slate-900/20 border border-slate-800 text-center space-y-4 max-w-md mx-auto">
              <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-500">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white">No products found</h3>
              <p className="text-sm text-slate-400">We couldn't find any products matching your active criteria. Try broadening your query.</p>
              <button
                onClick={clearAllFilters}
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold px-6 py-2.5 rounded-xl transition-all"
              >
                <RefreshCw className="w-4 h-4" /> Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
