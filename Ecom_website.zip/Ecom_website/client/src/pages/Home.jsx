import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ProductCard from '../components/ProductCard';
import { Sparkles, ArrowRight, Laptop, Shirt, Footprints, Watch, ShieldCheck, Truck, RefreshCw } from 'lucide-react';

export default function Home() {
  const { apiRequest } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const getFeaturedProducts = async () => {
      try {
        const data = await apiRequest('/products');
        // Let's feature the top 8 products (e.g. 2 from each category)
        setProducts(data.slice(0, 8));
      } catch (error) {
        console.error('Error fetching featured products:', error);
      } finally {
        setLoading(false);
      }
    };

    getFeaturedProducts();
  }, []);

  const categories = [
    { name: 'Electronics', icon: Laptop, count: '4 Items', color: 'from-blue-600 to-cyan-500', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80' },
    { name: 'Fashion', icon: Shirt, count: '4 Items', color: 'from-purple-600 to-pink-500', image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&auto=format&fit=crop&q=80' },
    { name: 'Shoes', icon: Footprints, count: '4 Items', color: 'from-orange-600 to-red-500', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&auto=format&fit=crop&q=80' },
    { name: 'Watches', icon: Watch, count: '4 Items', color: 'from-emerald-600 to-teal-500', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80' }
  ];

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Banner */}
      <section className="relative overflow-hidden min-h-[70vh] flex items-center py-20 px-4 sm:px-6 lg:px-8">
        {/* Glow Spheres */}
        <div className="absolute top-1/4 left-10 w-72 h-72 rounded-full bg-blue-600/25 blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-1/4 right-10 w-96 h-96 rounded-full bg-purple-600/20 blur-[150px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
          <div className="space-y-8 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs font-semibold text-blue-400">
              <Sparkles className="w-3.5 h-3.5" /> Introducing Aura Collection
            </div>
            
            <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white leading-none">
              Define Your <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                Aura of Luxury
              </span>
            </h1>

            <p className="text-lg text-slate-400 max-w-xl leading-relaxed">
              Discover a curated selection of premium electronics, fashion, footwear, and chronographs designed to complement your lifestyle.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/catalog"
                className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold px-8 py-4 rounded-2xl shadow-xl transition-all hover:shadow-[0_8px_30px_rgb(59,130,246,0.3)] hover:-translate-y-0.5 text-center"
              >
                Shop the Catalog <ArrowRight className="w-5 h-5" />
              </Link>
              <button
                onClick={() => navigate('/catalog?category=Watches')}
                className="inline-flex items-center justify-center bg-slate-900 hover:bg-slate-800/80 text-white font-bold px-8 py-4 rounded-2xl border border-slate-800 transition-all text-center"
              >
                Explore Chronographs
              </button>
            </div>
          </div>

          {/* Hero Image / Card Preview */}
          <div className="relative flex justify-center lg:justify-end">
            <div className="relative w-full max-w-md aspect-square rounded-[2rem] bg-gradient-to-tr from-slate-900 via-slate-850 to-slate-950 p-3 shadow-2xl border border-slate-800">
              <div className="w-full h-full rounded-[1.75rem] overflow-hidden relative group">
                <img
                  src="https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=800&auto=format&fit=crop&q=80"
                  alt="Feature watch hero"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent flex flex-col justify-end p-8">
                  <span className="text-xs font-bold text-blue-400 uppercase tracking-widest mb-1">Featured Arrival</span>
                  <h3 className="text-2xl font-bold text-white mb-2">Heritage 24k Gold Dress Watch</h3>
                  <p className="text-sm text-slate-300 line-clamp-1 mb-4">Exquisite Roman dial, automatic self-winding movement.</p>
                  <Link to="/product/prd_15" className="text-sm font-semibold text-white flex items-center gap-1 hover:text-blue-400 transition-colors">
                    View Product <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Value Props */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="p-8 rounded-3xl bg-slate-900/30 border border-slate-800 flex gap-5 items-start text-left">
          <div className="p-4 rounded-2xl bg-blue-600/10 text-blue-500">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-white mb-1">Express Delivery</h3>
            <p className="text-sm text-slate-400 leading-relaxed">Free, insured global shipping on all premium items above $150.</p>
          </div>
        </div>
        <div className="p-8 rounded-3xl bg-slate-900/30 border border-slate-800 flex gap-5 items-start text-left">
          <div className="p-4 rounded-2xl bg-purple-600/10 text-purple-500">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-white mb-1">Secure Authenticity</h3>
            <p className="text-sm text-slate-400 leading-relaxed">100% verified authentic brands with complete warranty coverage.</p>
          </div>
        </div>
        <div className="p-8 rounded-3xl bg-slate-900/30 border border-slate-800 flex gap-5 items-start text-left">
          <div className="p-4 rounded-2xl bg-cyan-600/10 text-cyan-500">
            <RefreshCw className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-white mb-1">Premium Returns</h3>
            <p className="text-sm text-slate-400 leading-relaxed">Hassle-free 30-day return policy with door-to-door courier pickup.</p>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center md:text-left space-y-2">
          <h2 className="text-3xl font-extrabold text-white">Featured Categories</h2>
          <p className="text-sm text-slate-400">Select a category to begin exploring the collections</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((cat, idx) => (
            <button
              key={idx}
              onClick={() => navigate(`/catalog?category=${cat.name}`)}
              className="group relative rounded-3xl overflow-hidden aspect-[4/5] w-full text-left border border-slate-800/80 hover:border-slate-700/80 transition-all hover:scale-[1.02] duration-300"
            >
              {/* Image background */}
              <img
                src={cat.image}
                alt={cat.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
              {/* Content */}
              <div className="absolute inset-x-0 bottom-0 p-6 flex flex-col justify-end space-y-2">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${cat.color} flex items-center justify-center text-white shadow-lg`}>
                  <cat.icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-xl text-white">{cat.name}</h3>
                <p className="text-xs text-slate-400">{cat.count}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Special Offers Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-[2.5rem] bg-gradient-to-r from-blue-900/40 via-indigo-950/40 to-purple-900/40 border border-slate-800/60 p-8 md:p-16 overflow-hidden flex flex-col md:flex-row justify-between items-center gap-8 text-left shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-blue-500/10 blur-[100px] pointer-events-none"></div>
          <div className="relative z-10 space-y-4 max-w-xl">
            <span className="text-xs font-bold text-purple-400 uppercase tracking-widest">Exclusive Mid-Season Sale</span>
            <h2 className="text-3xl md:text-5xl font-extrabold text-white leading-tight">
              Get Up To <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">30% Off</span> Premium Chronographs
            </h2>
            <p className="text-slate-400 text-sm md:text-base">
              Use checkout code <code className="bg-slate-900 text-blue-400 border border-slate-800 font-mono px-2 py-1 rounded text-sm">AURALUX30</code> to receive an immediate discount on your first order.
            </p>
          </div>
          <div className="relative z-10 flex-shrink-0">
            <button
              onClick={() => navigate('/catalog?category=Watches')}
              className="bg-white hover:bg-slate-100 text-slate-950 font-bold px-8 py-4 rounded-2xl shadow-lg transition-transform hover:scale-105 duration-200"
            >
              Explore Collection
            </button>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="text-center sm:text-left space-y-2">
            <h2 className="text-3xl font-extrabold text-white">Trending Arrivals</h2>
            <p className="text-sm text-slate-400">Explore this week's highest rated luxury picks</p>
          </div>
          <Link to="/catalog" className="text-blue-400 hover:text-blue-300 font-semibold text-sm flex items-center gap-1 group">
            View All Products <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse bg-slate-900/50 border border-slate-800 rounded-3xl aspect-[3/4]"></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
