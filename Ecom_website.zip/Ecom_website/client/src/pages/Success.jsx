import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { CheckCircle2, ArrowRight, Package, ShoppingBag } from 'lucide-react';

export default function Success() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('id') || 'MOCK_ORD_' + Math.floor(Math.random() * 1000000);

  return (
    <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-8 animate-fadeIn">
      {/* Success Badge */}
      <div className="relative flex justify-center">
        <div className="absolute inset-0 bg-emerald-500/10 blur-[50px] rounded-full w-32 h-32 mx-auto pointer-events-none"></div>
        <div className="w-24 h-24 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 relative z-10">
          <CheckCircle2 className="w-12 h-12" />
        </div>
      </div>

      {/* Message */}
      <div className="space-y-3">
        <h1 className="text-4xl font-extrabold text-white">Order Placed Successfully!</h1>
        <p className="text-slate-400">
          Thank you for shopping with Aura Lux. Your transaction is complete and your item is being processed.
        </p>
      </div>

      {/* Order info details */}
      <div className="p-6 rounded-3xl bg-slate-900/40 border border-slate-800 text-left space-y-4 max-w-md mx-auto">
        <div className="flex justify-between items-center text-sm border-b border-slate-800 pb-3">
          <span className="text-slate-400">Order ID:</span>
          <span className="font-mono font-bold text-white text-xs select-all bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-850">
            {orderId}
          </span>
        </div>
        <div className="flex justify-between items-center text-sm">
          <span className="text-slate-400">Delivery Status:</span>
          <span className="font-bold text-emerald-400">Processing</span>
        </div>
        <p className="text-xs text-slate-500 leading-relaxed">
          An email confirmation has been sent to your registered address. You can track your shipment live in your profile dashboard.
        </p>
      </div>

      {/* Navigation Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
        <Link
          to="/profile"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3.5 px-8 rounded-2xl border border-slate-800 transition-colors"
        >
          <Package className="w-4 h-4 text-blue-400" /> View Order History
        </Link>
        <Link
          to="/"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold py-3.5 px-8 rounded-2xl transition-all shadow-xl hover:shadow-[0_8px_30px_rgb(59,130,246,0.3)]"
        >
          <ShoppingBag className="w-4 h-4" /> Continue Shopping <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
