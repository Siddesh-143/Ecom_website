import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogOut, Package, Mail, User, Calendar, ShieldCheck, ChevronDown, ChevronUp } from 'lucide-react';

export default function Profile() {
  const { user, logout, apiRequest } = useAuth();
  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrder, setExpandedOrder] = useState(null);

  // Redirect if guest
  useEffect(() => {
    if (!user) {
      navigate('/login?redirect=profile');
    }
  }, [user, navigate]);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;
      try {
        const data = await apiRequest('/orders/myorders');
        setOrders(data);
      } catch (err) {
        console.error('Error fetching my orders:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, [user]);

  const toggleOrderExpand = (orderId) => {
    setExpandedOrder((prev) => (prev === orderId ? null : orderId));
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (!user) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-left space-y-10">
      <div>
        <h1 className="text-4xl font-extrabold text-white">Customer Dashboard</h1>
        <p className="text-sm text-slate-400 mt-1">Manage your premium profile and track order updates.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Left Column: Profile Card */}
        <div className="lg:col-span-1 p-8 rounded-3xl bg-slate-900/40 border border-slate-800 space-y-8 relative overflow-hidden">
          <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full bg-blue-500/5 blur-[80px] pointer-events-none"></div>
          
          <div className="space-y-6 text-center lg:text-left relative z-10">
            {/* User Avatar */}
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-white text-3xl font-extrabold shadow-xl mx-auto lg:mx-0">
              {user.name.charAt(0).toUpperCase()}
            </div>

            <div className="space-y-1.5">
              <h3 className="text-xl font-bold text-white">{user.name}</h3>
              <p className="text-xs text-slate-400">Premium Member</p>
            </div>
          </div>

          <div className="border-t border-slate-800/60 pt-6 space-y-4 text-sm text-slate-300 relative z-10">
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-blue-500" />
              <span>{user.name}</span>
            </div>
            <div className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-blue-500" />
              <span className="truncate">{user.email}</span>
            </div>
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-4 h-4 text-blue-500" />
              <span>Verified Account</span>
            </div>
          </div>

          <button
            onClick={() => {
              logout();
              navigate('/');
            }}
            className="w-full bg-slate-950 border border-slate-800 hover:border-red-500/25 hover:text-red-400 text-slate-400 font-bold py-3.5 px-6 rounded-2xl transition-all flex items-center justify-center gap-2 relative z-10"
          >
            <LogOut className="w-4 h-4" /> Logout Account
          </button>
        </div>

        {/* Right Column: Order History */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center gap-2.5">
            <Package className="w-5 h-5 text-blue-500" />
            <h3 className="text-xl font-bold text-white">Order History</h3>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[...Array(2)].map((_, i) => (
                <div key={i} className="animate-pulse bg-slate-900/40 border border-slate-800 rounded-3xl h-24"></div>
              ))}
            </div>
          ) : orders.length === 0 ? (
            <div className="p-12 rounded-3xl bg-slate-900/20 border border-slate-800 text-center space-y-4 max-w-md mx-auto">
              <div className="w-16 h-16 rounded-full bg-slate-850 flex items-center justify-center mx-auto text-slate-600">
                <Package className="w-7 h-7" />
              </div>
              <h4 className="text-lg font-bold text-white">No orders placed yet</h4>
              <p className="text-sm text-slate-400 leading-relaxed">Your order records are currently empty. Explore our catalog to place your first order.</p>
              <button
                onClick={() => navigate('/catalog')}
                className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-6 py-2.5 rounded-xl transition-all"
              >
                Go Shop
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => {
                const isExpanded = expandedOrder === order._id;
                return (
                  <div
                    key={order._id}
                    className="rounded-3xl border border-slate-800/80 bg-slate-900/30 overflow-hidden transition-all duration-300"
                  >
                    {/* Collapsed Header */}
                    <div
                      onClick={() => toggleOrderExpand(order._id)}
                      className="p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 cursor-pointer hover:bg-slate-900/10 transition-colors"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-xs font-bold text-white">{order._id}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            order.status === 'Delivered'
                              ? 'bg-emerald-950/40 border-emerald-500/20 text-emerald-400'
                              : order.status === 'Cancelled'
                              ? 'bg-red-950/40 border-red-500/20 text-red-400'
                              : 'bg-blue-950/40 border-blue-500/20 text-blue-400'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-slate-500">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Placed on {formatDate(order.createdAt)}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between w-full sm:w-auto gap-6">
                        <div className="text-left sm:text-right">
                          <p className="text-xs text-slate-500">Total Charged</p>
                          <p className="font-extrabold text-white text-lg">${order.totalPrice.toFixed(2)}</p>
                        </div>
                        <div className="text-slate-400">
                          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                        </div>
                      </div>
                    </div>

                    {/* Expanded Content */}
                    {isExpanded && (
                      <div className="p-6 border-t border-slate-800/60 bg-slate-950/30 space-y-6 animate-fadeIn">
                        {/* Order Items */}
                        <div className="space-y-4">
                          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Items Purchased</h4>
                          <div className="space-y-3">
                            {order.items.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-4 justify-between text-sm">
                                <div className="flex items-center gap-3">
                                  <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover border border-slate-800 flex-shrink-0" />
                                  <div>
                                    <p className="font-bold text-white text-xs">{item.name}</p>
                                    <p className="text-[10px] text-slate-500">Quantity: {item.quantity} × ${item.price.toFixed(2)}</p>
                                  </div>
                                </div>
                                <span className="font-bold text-white text-xs">${(item.price * item.quantity).toFixed(2)}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Shipment Info */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-slate-800/60 text-xs">
                          <div className="space-y-2">
                            <h4 className="font-bold text-slate-500 uppercase tracking-widest">Shipping Destination</h4>
                            <p className="text-white font-medium">{order.shippingAddress.fullName}</p>
                            <p className="text-slate-400 leading-relaxed">
                              {order.shippingAddress.address}, {order.shippingAddress.city}, <br />
                              {order.shippingAddress.postalCode}, {order.shippingAddress.country}
                            </p>
                          </div>
                          
                          <div className="space-y-2">
                            <h4 className="font-bold text-slate-500 uppercase tracking-widest">Payment Configuration</h4>
                            <p className="text-white font-medium">{order.paymentMethod}</p>
                            <p className="text-slate-400">
                              Payment status:{' '}
                              <span className={`font-semibold ${order.paymentStatus === 'Paid' ? 'text-emerald-400' : 'text-amber-400'}`}>
                                {order.paymentStatus}
                              </span>
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
