import React, { createContext, useState, useEffect, useContext } from 'react';
import { mockProducts } from '../utils/mockProducts';

const AuthContext = createContext();

const API_URL = 'http://localhost:5000/api';

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load user from localStorage on init
  useEffect(() => {
    const storedUser = localStorage.getItem('aura_user');
    const storedToken = localStorage.getItem('aura_token');
    if (storedUser && storedToken) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // Helper for requests
  const apiRequest = async (endpoint, options = {}) => {
    const token = localStorage.getItem('aura_token');
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(`${API_URL}${endpoint}`, {
        ...options,
        headers,
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'Something went wrong');
      }
      return data;
    } catch (err) {
      // If server is down, fallback to Mock local simulation
      if (err.message.includes('Failed to fetch') || err.message.includes('Load failed')) {
        console.warn('Backend server offline. Simulating response locally.');
        return simulateLocalApi(endpoint, options);
      }
      throw err;
    }
  };

  // Mock API Simulation for offline demo
  const simulateLocalApi = async (endpoint, options) => {
    await new Promise((resolve) => setTimeout(resolve, 500)); // simulate delay
    const body = options.body ? JSON.parse(options.body) : null;
    const mockUsers = JSON.parse(localStorage.getItem('mock_users') || '[]');

    if (endpoint === '/auth/register') {
      const { name, email, password } = body;
      if (mockUsers.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
        throw new Error('User already exists');
      }
      const newUser = { _id: `mock_usr_${Date.now()}`, name, email: email.toLowerCase(), password };
      mockUsers.push(newUser);
      localStorage.setItem('mock_users', JSON.stringify(mockUsers));
      
      const sessionUser = { _id: newUser._id, name: newUser.name, email: newUser.email };
      return { ...sessionUser, token: `mock_jwt_token_${newUser._id}` };
    }

    if (endpoint === '/auth/login') {
      const { email, password } = body;
      const foundUser = mockUsers.find(
        (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );
      // fallback default credentials
      if (!foundUser && email === 'demo@aura.com' && password === 'password') {
        const defaultUser = { _id: 'mock_usr_default', name: 'Demo Customer', email: 'demo@aura.com' };
        return { ...defaultUser, token: 'mock_jwt_token_default' };
      }
      if (!foundUser) {
        throw new Error('Invalid email or password');
      }
      const sessionUser = { _id: foundUser._id, name: foundUser.name, email: foundUser.email };
      return { ...sessionUser, token: `mock_jwt_token_${foundUser._id}` };
    }

    if (endpoint === '/auth/forgot-password') {
      const { email } = body;
      const userExists = mockUsers.some((u) => u.email.toLowerCase() === email.toLowerCase()) || email === 'demo@aura.com';
      if (!userExists) {
        throw new Error('No account found with this email');
      }
      return {
        message: 'Password reset code generated successfully',
        resetCode: Math.floor(100000 + Math.random() * 900000).toString(),
        email
      };
    }

    if (endpoint === '/auth/reset-password') {
      const { email, password } = body;
      const userIdx = mockUsers.findIndex((u) => u.email.toLowerCase() === email.toLowerCase());
      if (userIdx !== -1) {
        mockUsers[userIdx].password = password;
        localStorage.setItem('mock_users', JSON.stringify(mockUsers));
      }
      return { message: 'Password reset successful' };
    }

    if (endpoint.startsWith('/products')) {
      const url = new URL(endpoint, 'http://localhost');
      const search = url.searchParams.get('search') || '';
      const category = url.searchParams.get('category') || '';

      // Check if looking for single product
      const pathParts = url.pathname.split('/');
      const prodId = pathParts[2]; // /products/:id

      if (prodId) {
        const prod = mockProducts.find((p) => p._id === prodId);
        if (prod) return prod;
        throw new Error('Product not found');
      }

      let results = [...mockProducts];
      if (category) {
        results = results.filter((p) => p.category.toLowerCase() === category.toLowerCase());
      }
      if (search) {
        const searchLower = search.toLowerCase();
        results = results.filter((p) => p.name.toLowerCase().includes(searchLower));
      }
      return results;
    }

    if (endpoint === '/orders' && options.method === 'POST') {
      const mockOrders = JSON.parse(localStorage.getItem('mock_orders') || '[]');
      const sessionUser = JSON.parse(localStorage.getItem('aura_user'));
      const newOrder = {
        _id: `mock_ord_${Date.now()}`,
        user: sessionUser ? sessionUser._id : 'mock_usr_guest',
        items: body.items,
        shippingAddress: body.shippingAddress,
        paymentMethod: body.paymentMethod,
        paymentStatus: body.paymentMethod === 'Online Payment' ? 'Paid' : 'Pending',
        totalPrice: body.totalPrice,
        status: 'Processing',
        createdAt: new Date().toISOString()
      };
      mockOrders.push(newOrder);
      localStorage.setItem('mock_orders', JSON.stringify(mockOrders));
      return newOrder;
    }

    if (endpoint === '/orders/myorders' && options.method === 'GET') {
      const mockOrders = JSON.parse(localStorage.getItem('mock_orders') || '[]');
      const sessionUser = JSON.parse(localStorage.getItem('aura_user'));
      const userId = sessionUser ? sessionUser._id : 'mock_usr_default';
      const userOrders = mockOrders.filter((o) => o.user === userId);
      return userOrders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    throw new Error('Endpoint not implemented in mock API');
  };

  const login = async (email, password) => {
    setError(null);
    setLoading(true);
    try {
      const data = await apiRequest('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      setUser(data);
      localStorage.setItem('aura_user', JSON.stringify(data));
      localStorage.setItem('aura_token', data.token);
      setLoading(false);
      return data;
    } catch (err) {
      setError(err.message);
      setLoading(false);
      throw err;
    }
  };

  const register = async (name, email, password) => {
    setError(null);
    setLoading(true);
    try {
      const data = await apiRequest('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name, email, password }),
      });
      setUser(data);
      localStorage.setItem('aura_user', JSON.stringify(data));
      localStorage.setItem('aura_token', data.token);
      setLoading(false);
      return data;
    } catch (err) {
      setError(err.message);
      setLoading(false);
      throw err;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('aura_user');
    localStorage.removeItem('aura_token');
  };

  const forgotPasswordRequest = async (email) => {
    setError(null);
    try {
      return await apiRequest('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email }),
      });
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const resetPasswordRequest = async (email, password) => {
    setError(null);
    try {
      return await apiRequest('/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        login,
        register,
        logout,
        forgotPassword: forgotPasswordRequest,
        resetPassword: resetPasswordRequest,
        apiRequest,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
