This zip excludes the node_modules folders (server/node_modules and client/node_modules)
to keep the file size small. These folders contain reinstallable dependencies, not your
own project files, so nothing of yours is missing.

To restore them after unzipping, run:

  cd Ecom_website/server && npm install
  cd ../client && npm install
